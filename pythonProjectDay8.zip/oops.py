# #Object Orient Programming
#
# #functional and object-oriented programming
#
# #object-oriented programming follow entities and relationships
#
# #in-real-world
# #
# # Animals -> class
# # lion -> object of animal class
# # each object possess it's own charecteristic that will become a method or varible
#
# # sound - characterstic
# # lion -
# # cat -
# # elephant -
#
# #banking
# # account - class
# # savings, current, FD, RD
#
# # interest rate - characteristic
# # saving account - 0.5
# # current account - 0.5
# # FD - 2
# # RD - 5
#
# #class, objects, inheritance, encapsulation, polymorphism
#
# #encapsulation - binding data and method together
# # interest_rate - data
# # get_interest_rate() method which uses interest_rate data
#
# #Account B having 1000$ in FD and what will be rate of interest
# # 1000$ * 2 -> get_interest_rate()
#
# #inheritance - kind of common characteristic upon parent - child
# #Account - credit and debit
# #Animals - sound
# #elephant
# #lion
#
# class Person():
#     name
#
# class Employee(Person):
#     name
#
# class SportsPerson(Person):
#     name
#
# #polymorphism - taking one more than one form, operator overlaoding,
# #function overloading - same name but with different number / type of arguments
# class Volume
#     def volume(self):
#
# class Cube(volume): a*a*a
#
# class Square(volume):a*a
#
# class Circle(volume): pi * r * r

"""
One of the popular approach of solving a real problem is by creating and using projects
ecommerce - price is a attribute purchase is a behaviour
retail billing
car sales

An object has two characteristics:
attributes - name, age, gender, color are properties
behaviour - singing, dancing, programming

- creating reusable code - DRY


Class car
   color
   price -
   brand
   manufacture_data -

   mileage
   on_road_price
   sound
   price of fuel based on engine mode - EV, FB
"""
"""
Class - blueprint of the object

Car class, Audi is an object, Tesla is an object
"""

class Bird():
    pass
class Parrot(Bird):
    pass

"""
object creation

Object - instanctiation of the class

"""
class Parrot:
    pass

parrot1 = Parrot()
print(type(parrot1))

#constructor - a special method of the class for creating and
#initializing an object instance of the class

class Parrot:

    def __init__(self,color,age,weight):
        self.color_given = color
        self.age_given = age
        self.weight_given = weight

parrot1 = Parrot("white",'13',100)
print(parrot1.color_given)
print(parrot1.age_given)
print(parrot1.weight_given)
# print(parrot1.weight_category)

parrot2 = Parrot(color="brown",age='18',weight=0)
print(parrot2.color_given,parrot2.age_given,parrot2.weight_given)

"""
self is a reference to the current instance(object) of the class and is used
to access variables that belongs to the class
"""

class Parrot:

    def __init__(self,color,age,weight):
        self.color_given = color
        self.age_given = age
        self.weight_given = weight
        if weight > 0 and weight < 50:
            self.weight_category = "underweight"
        elif weight > 50 and weight < 70:
            self.weight_category = "normal"
        elif weight > 70:
            self.weight_category = "overweight"
        else:
            self.weight_category = "unknown"

parrot1 = Parrot("white",'13',100)
print(parrot1.color_given)
print(parrot1.age_given)
print(parrot1.weight_given)
print(parrot1.weight_category)

parrot2 = Parrot(color="brown",age='18',weight=0)
print(parrot2.color_given,parrot2.age_given,parrot2.weight_given, parrot2.weight_category)

class Calculator:
    def __init__(self):
        pass

    def sum(self,a,b):
        return a + b

cal1 = Calculator()
print(cal1.sum(2,3))

class CalculatorwithTwoNumbers:
    def __init__(self,a,b):
        self.first_number = a
        self.second_number = b

    def sum(self):
        return self.first_number + self.second_number

    def mul(self):
        return self.first_number * self.second_number

    def div(self):
        return self.first_number // self.second_number

    def pow(self):
        return self.first_number ** self.second_number

cal2 = CalculatorwithTwoNumbers(a=8,b=10)
print(cal2.sum(),cal2.mul(),cal2.div(),cal2.pow())

#Methods - behaviour
"""
Methods are functions defined inside the body of a class, They are used to define the 
behaviour of an object
"""

class Parrot:

    #attributes
    def __init__(self,name,age):
        self.name = name
        self.age = age

    #method - behaviours
    def speak(self,sentence):
        return f"{self.name} of age {self.age} speaks {sentence}"

    def sing(self,song):
        return f"{self.name} of age {self.age} sings {song}"

    def dancing(self):
        return f"{self.name} of age {self.age} is now dancing"

p1 = Parrot("j",2)
print(p1.sing("ooooo"))
print(p1.speak("Hi"))
print(p1.dancing())

#design a class called Planets and attibutes and behaviour

#design a class called FeverDetector which will say the behaviour of having Fever True or False
#based on the attribute body temperature![](../../AppData/Local/Temp/download.jpg)

class Planet:
    def __init__(self,name,size,kms): #constructor, return not allowed
        self.name = name
        self.size = size
        self.kms = kms

    def display_data(self):
        return f"The planet of {self.name} and of size {self.size} is {self.kms} away form earth"

"""
Inheritance - way of creating a new class for using details of an existing class without modifying it.
The newly formed class is a derived clas ( or sub class or child class ). similarly, the existing class
is a base class ( or super class or parent class )

a->b->c
"""
#parent class
class Bird:
    def __init__(self):
        print("This is super class")

    def get_family(self):
        print("Bird")

    def get_fly(self):
        print("fly")

class Ostrich(Bird):
    def __init__(self,name):
        super().__init__()
        self.name = name

    def get_family(self):
        super().get_family()
        print("Ostrich, " + self.name)

    def run(self):
        print("run")

ostrich1 = Ostrich("ostrich1")
ostrich1.get_family()

# Sports -> Cricket, Football, Tennis, Rubgy
##create a Parent class called Person
## and initialize the constructor with firstname, lastname, age,gender
## create a Child class called Employee
## inherit the base class constructor with the employee id
## create the display data method which will output the firstname,lastname,age,gender and employee id

class Person:
    def __init__(self,firstname,lastname,age,gender):
        self.first_name = firstname
        self.last_name = lastname
        self.age = age
        self.gender = gender

    def print_data(self):
        return f"{self.first_name}, {self.last_name}, {self.gender}, {self.age}"

class Employee(Person):
    def __init__(self,firstname,lastname,gender,age,employee_id):
        super().__init__(firstname,lastname,gender,age)
        self.employee_id = employee_id

    def print_result(self):
        result = super().print_data()
        result = result + "," + self.employee_id
        return result

#person object
#employee
emp1 = Employee("Sugumar","V","male",30,"xxxx")
print(emp1.print_result())